import Vapor
import VaporSQLite
import HTTP
import Foundation

class Customer : NodeRepresentable {
    
    var customerId :Int!
    var firstName :String!
    var lastName :String!
    
    func makeNode(context: Context) throws -> Node {
        return try Node(node :["customerId":self.customerId,"firstName":self.firstName,"lastName":self.lastName])
    }
}


let drop = Droplet()
try drop.addProvider(VaporSQLite.Provider.self)

drop.get("version") { request in
    let result = try drop.database?.driver.raw("SELECT sqlite_version()")
    return try JSON(node :result)
}

drop.post("customers","create") { request in
    
    guard let firstName = request.json?["firstName"]?.string,
        let lastName = request.json?["lastName"]?.string else {
            throw Abort.badRequest
    }
    
    let result = try drop.database?.driver.raw("INSERT INTO Customers(firstName,lastName) VALUES(?,?)",[firstName,lastName])
    
    return try JSON(node :result)
}


class PasswordValidator : ValidationSuite {
    
    static func validate(input value: String) throws {
        
        let evaluation = !OnlyAlphanumeric.self && Count.containedIn(low: 5, high: 12)
        
        try evaluation.validate(input: value)
        
    }
    
}

// Custom Validation
drop.post("register") { request in
    
    guard let inputPassword = request.data["password"]?.string else {
        throw Abort.badRequest
    }
    
    let isValid = inputPassword.passes(PasswordValidator.self)
    
   // let isTested = try inputPassword.tested(by: PasswordValidator.self)
    
    let password :Valid<PasswordValidator> = try inputPassword.validated()
    
    return "Validated \(password)"
    
}





















drop.post("keys") { request in
    
    guard let keyCode = request.data["keyCode"]?.string else {
        throw Abort.badRequest
    }
    
    let key :Valid<Matches<String>> = try keyCode.validated(by :Matches("Secret"))
    return "Validated \(key)"
    
}

drop.post("unique") { request in
    
    // a,b,c
    guard let inputCommaSeparated = request.data["input"]?.string else {
        throw Abort.badRequest
    }
    
    let unique :Valid<Unique<[String]>> = try inputCommaSeparated.components(separatedBy: ",").validated()
    
    return "Validated \(unique)"
}




























// customers/all
drop.get("customers","all") { request in
    
    var customers = [Customer]()
    
    let result = try drop.database?.driver.raw("SELECT customerId,firstName,lastName FROM Customers;")
    
    guard let nodeArray = result?.nodeArray else {
        return try JSON(node :customers)
    }
    
    for node in nodeArray {
        
        let customer = Customer()
        customer.customerId = node["customerId"]?.int
        customer.firstName = node["firstName"]?.string
        customer.lastName = node["lastName"]?.string
        
        customers.append(customer)
    }
    
    return try JSON(node: customers)
    
}


// parameters 

drop.get("users",Int.self) { request, userId in
    
//    guard let userId = request.parameters["id"]?.int else {
//        throw Abort.notFound
//    }
//    
    return "UserId is \(userId)"
}


//POST

drop.post("users") { request in
    
    guard let firstName = request.json?["firstName"]?.string,
          let lastName = request.json?["lastName"]?.string
    else {
        throw Abort.badRequest
    }
    
    return firstName + ", " + lastName
}













drop.get("hello") { request in
    return "Hello World"
}

drop.get("404") { request in
    throw Abort.notFound
}

drop.get("error") { request in
    throw Abort.custom(status: .badRequest, message: "Sorry!")
}

drop.get("vapor") { request in
    return Response(redirect: "http://vapor.codes")
}

drop.get("foo","bar") { request in
    return "foo bar"
}






drop.get("names") { request in
    
    return try JSON(node :["names":["Alex","Mary","John"]])
}

drop.get("customer") { request in
    
    let customer = Customer()
    customer.firstName = "John"
    customer.lastName = "Doe"
    
    return try JSON(node :customer)
    
}

drop.run()
